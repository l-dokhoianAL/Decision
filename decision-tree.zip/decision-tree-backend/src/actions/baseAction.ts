export abstract class BaseAction {
  abstract execute(): void;
}